Import Project in Eclipse 
Java version used : Java 8
Use tomcat 8+ for deployment
URL to access : http://localhost:8080/StockRecommendation/StockServlet/getBatchStock