package com.stock.output;

import com.google.gson.annotations.SerializedName;

public class Metadata {

	@SerializedName("1. Information")
	private String info;
	
	@SerializedName("2. Notes")
	private String notes;
	
	@SerializedName("3. Time Zone")
	private String timeZone;

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	@Override
	public String toString() {
		return "Metadata [info=" + info + ", notes=" + notes + ", timeZone=" + timeZone + "]";
	}

}
