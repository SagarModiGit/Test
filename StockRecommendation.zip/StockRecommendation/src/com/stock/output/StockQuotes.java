package com.stock.output;

import com.google.gson.annotations.SerializedName;

public class StockQuotes {

	@SerializedName("1. symbol")
	private String symbol;

	@SerializedName("2. price")
	private double price;

	@SerializedName("3. volume")
	private long volume;

	@SerializedName("4. timestamp")
	private String timestamp;

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public long getVolume() {
		return volume;
	}

	public void setVolume(long volume) {
		this.volume = volume;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "StockQuotes [symbol=" + symbol + ", price=" + price + ", volume=" + volume + ", timestamp=" + timestamp
				+ "]";
	}

}
