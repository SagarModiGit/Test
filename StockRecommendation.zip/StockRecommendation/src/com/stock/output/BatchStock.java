package com.stock.output;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class BatchStock {

	@SerializedName("Meta Data")
	private Metadata metadata;

	@SerializedName("Stock Quotes")
	private List<StockQuotes> stockQuotes;

	public Metadata getMetadata() {
		return metadata;
	}

	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}

	public List<StockQuotes> getStockQuotes() {
		return stockQuotes;
	}

	public void setStockQuotes(List<StockQuotes> stockQuotes) {
		this.stockQuotes = stockQuotes;
	}

	@Override
	public String toString() {
		return "BatchStock [metadata=" + metadata + ", stockQuotes=" + stockQuotes + "]";
	}
	
	

}
