package com.stock.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HttpsURLConnection;

public class ConnectionUtility {
	
	public static String executeService(String url, String method, Map<String, String> headers, String body) throws Exception {
		
		System.out.println("Url : " + url);
		
		URL serviceUrl = new URL(url); 
		
		HttpsURLConnection con = null;
		OutputStream out =  null;
		InputStream in = null;
		BufferedReader reader = null;
		
		try {
			
			con = (HttpsURLConnection) serviceUrl.openConnection();
			
			con.setDoInput(true);
			con.setDoOutput(true);
			
			if (method != null) {
				con.setRequestMethod(method);
			}
			
			
			if (headers != null && !headers.isEmpty()) {
				for (Entry<String, String> entry : headers.entrySet()) {
					System.out.println("Adding header : " + entry);
					con.setRequestProperty(entry.getKey(), entry.getValue());
				}
			}
						
			
			if (body != null && !body.isEmpty()) {
				out = con.getOutputStream();
				out.write(body.getBytes());
				out.flush();
			}
			
			
			
			int responseCode = con.getResponseCode();
			
			System.out.println("Response code from service : " + responseCode);
			
			if (responseCode >= 400) {
				in = con.getErrorStream();
			} else {
				in = con.getInputStream();
			}
			
			String line = "";
			StringBuilder sbuilder = new StringBuilder();
			reader = new BufferedReader(new InputStreamReader(in));
						
			while ((line = reader.readLine()) != null) {
				sbuilder.append(line);
			}
			
			System.out.println("Response from service : : " + sbuilder.toString());
			
			return sbuilder.toString();
			
		} finally {
			releaseResources(con, out, in, reader);
		}
		
	}
	
	private static void releaseResources(HttpURLConnection con, OutputStream out, InputStream in, BufferedReader reader) {
		try {
			if (con != null) con.disconnect();
			if (out != null) out.close();
			if (in != null) in.close();
			if (reader != null) reader.close(); 				
		} catch (Exception e) {
			
		}
	}

}
