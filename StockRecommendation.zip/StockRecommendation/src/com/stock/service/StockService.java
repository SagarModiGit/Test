package com.stock.service;

import com.google.gson.Gson;
import com.stock.output.BatchStock;
import com.stock.util.ConnectionUtility;

public class StockService {
	
	public BatchStock getBatchStockList() throws Exception {
		
		String alphVantageBaseURl = 
				"https://www.alphavantage.co/query?function=BATCH_STOCK_QUOTES&symbols=MSFT,FB,AAPL&apikey=K39ETVCB4RUFWDVT";
		String reponse = ConnectionUtility.executeService(alphVantageBaseURl, "GET", null, null);
		
		Gson gson = new Gson();
		BatchStock batchStock = gson.fromJson(reponse, BatchStock.class);
		
		System.out.println("Java Object : " + batchStock);
		
		return batchStock;
	}	
}